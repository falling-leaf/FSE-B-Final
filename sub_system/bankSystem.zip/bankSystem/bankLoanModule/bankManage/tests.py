from django.test import TestCase, Client
from django.urls import reverse
from bankDatabase import models
import json

class loanManageTest(TestCase):
    def setUp(self):
        self.employee = models.AuthorityEmployee.objects.create(
            employee_name="阿卜杜",
            identity_card="320215789354120315",
            employee_sex=1,
            phone_number="19505776812",
            occupation_name="贷款审核员",
            is_employeed=1,
            other_information="smoke test examiner"
        )

        self.client = Client()

    def test_manage_loan_examiner(self):
        request = {
            "operation": "add",
            "employee_id": self.employee.employee_id,
            "account": "test_examiner",
            "password": "test_password"
        }
        response = self.client.post(reverse('manage_loan_examiner'), data=request)
        self.assertEqual(response.status_code, 200)
        print(response.content.decode())