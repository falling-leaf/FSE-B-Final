from django.apps import AppConfig


class BankmanageConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "bankManage"
