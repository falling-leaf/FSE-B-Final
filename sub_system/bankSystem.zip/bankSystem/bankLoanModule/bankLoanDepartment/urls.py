from django.urls import path
from . import views

urlpatterns = [
    path('commitLoanApplication/', views.commitLoanApplication, name="commit_loan_application"),
    path('searchAllNeedRepayLoanRecord/', views.searchAllNeedRepayLoanRecord, name="search_all_need_repay_loan_record"),
    path('unrepayLoanRecordReminder/', views.unrepayLoanRecordReminder, name="unrepay_loan_record_reminder"),
    path('searchAllLoanApplicationByUser/', views.searchAllLoanApplicationByUser, name="search_all_loan_application_by_user"),
    path('userRepayLoanByAccount/', views.userRepayLoanByAccount, name="user_repay_loan_by_account"),
    path('showAllLoanApplicationUnapproved/', views.showAllLoanApplicationUnapproved, name="show_all_loan_application_unapproved"),
    path('showAllLoanApplicationUnlent/', views.showAllLoanApplicationUnlent, name="show_all_loan_application_unlent"),
    path('updateCreditLimit/', views.updateCreditLimit, name="update_credit_limit"),
    path('approvalLoanApplication/', views.approvalLoanApplication, name="approval_loan_application"),
    path('lenderLoanApplication/', views.lenderLoanApplication, name="lender_loan_application"),
]