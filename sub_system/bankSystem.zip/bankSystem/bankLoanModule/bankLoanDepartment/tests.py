import datetime
from django.test import TestCase, Client
from django.urls import reverse
from bankDatabase import models
import json


'''

2024.6.7
在更换了数据的获取方式后
即从request.POST.get到json解读body.get
以下测试代码不可用

'''

# Create your tests here.
class commitLoanApplicationTestCase(TestCase):
    def setUp(self):
        # Create users and their credit cards
        self.olineUser = models.OlineUser(phone_number="18205877953", identity_card="330204197503330578", person_name="开热马",
                                sex=0, trading_authority=1, loan_authority=1, foreign_exchange_authority=1,
                                annual_income=1000000, property_valuation=600000, occupational_type="会计", service_year=5)
        self.olineUser.setPassword("20050202")
        self.olineUser.save()

        self.account = models.Account(identity_card=self.olineUser.identity_card, card_type=1, balance=2500000, current_deposit=2499950,
                                  uncredited_deposit=50, is_frozen=0, is_lost=0)
        self.account.setPassword("050202")
        self.account.save()

        # Create the required administrators
        self.employee1 = models.AuthorityEmployee.objects.create(employee_name="阿卜杜", identity_card="320215789354120315",
                                                            employee_sex=1, phone_number="19505776812",
                                                            occupation_name="贷款审核员", is_employeed=1,
                                                            other_information="smoke test examiner")
        self.employee2 = models.AuthorityEmployee.objects.create(employee_name="凯撒加图索", identity_card="302125486516468597",
                                                            employee_sex=0, phone_number="15642829999",
                                                            occupation_name="贷款部门经理", is_employeed=1,
                                                            other_information="smoke test loan manager")

        self.loanExaminer = models.LoanExaminer(employee_id=self.employee1, account="loanexaminer2",
                                           other_information="")
        self.loanExaminer.setPassword("123456789")
        self.loanExaminer.save()

        self.loanManager = models.LoanDepartmentManager(employee_id=self.employee2, account="loanmanager2",
                                                   other_information="")
        self.loanManager.setPassword("123456789")
        self.loanManager.save()

        '''
        用户提交贷款申请 -> 审核员审批贷款申请 -> 部门经理发放贷款 -> 用户还款
        '''

        self.loan_application_request = {
            'identity_card': self.olineUser.identity_card,
            'account_id': self.account.account_id,
            'amount': 500000,
            'loan_duration': 12,
            'remark': "smoke test"
        }
        self.loanApplication = models.LoanApplication.objects.create(identity_card=self.olineUser.identity_card, account_id=self.account,
                                              amount=500000, loan_duration=12, remark="smoke test")

        self.loan_approval_request = {
            "loan_examiner_id": self.loanExaminer.loan_examiner_id,
            "application_id": self.loanApplication.application_id,
            "result": True,
            "remark": "smoke test"
        }
        self.loanApproval = models.LoanApproval.objects.create(loan_examiner_id=self.loanExaminer, application_id=self.loanApplication,
                                                   result=True, remark="smoke test")

        self.lender = models.Lender.objects.create(
            loan_manager_id=self.loanManager,
            application_id=self.loanApplication,
            result=True,
            remark="smoke test"
        )
        self.loanRecord = models.LoanRecord.objects.create(
            loan_examiner_id=self.loanExaminer,
            loan_manager_id=self.loanManager,
            application_id=self.loanApplication,
            remark="smoke test"
        )
        self.loanRecord.setEndTime(self.loanApplication.loan_duration)
        self.loanRecord.save()

        self.client = Client()

    def test_commit_loan_application(self):
        request = json.dumps(self.loan_application_request)
        response = self.client.post(reverse('commit_loan_application'), data=request)
        self.assertEqual(response.status_code, 200)
        print(response.content.decode())

    def test_search_all_loan_application_by_user(self):
        request = {
            "identity_card": self.olineUser.identity_card
        }

        response = self.client.post(reverse('search_all_loan_application_by_user'), data=request)
        self.assertEqual(response.status_code, 200)

        response_content = response.content.decode('utf-8')
        formatted_response = json.dumps(json.loads(response_content), indent=4, ensure_ascii=False)
        # print(formatted_response)

    def test_show_all_loan_application_unapproved(self):
        response = self.client.post(reverse('show_all_loan_application_unapproved'))
        response_content = response.content.decode('utf-8')
        formatted_response = json.dumps(json.loads(response_content), indent=4, ensure_ascii=False)
        # print(formatted_response)

    # def test_approval_loan_application(self):
    #     response = self.client.post(reverse('approval_loan_application'), data=self.loan_approval_request)
    #     response_content = response.content.decode('utf-8')
    #     formatted_response = json.dumps(json.loads(response_content), indent=4, ensure_ascii=False)
    #     print(formatted_response)

    # def test_lender_loan_application(self):
    #     request = {
    #         "loan_manager_id": self.loanExaminer.loan_examiner_id,
    #         "approval_id": self.loanApproval.approval_id,
    #         "result": True
    #     }
    #
    #     response = self.client.post(reverse('lender_loan_application'), data=request)
    #     response_content = response.content.decode('utf-8')
    #     formatted_response = json.dumps(json.loads(response_content), indent=4, ensure_ascii=False)
    #     print(formatted_response)

    def test_show_all_loan_application_unlent(self):
        response = self.client.post(reverse('show_all_loan_application_unlent'))
        response_content = response.content.decode('utf-8')
        formatted_response = json.dumps(json.loads(response_content), indent=4, ensure_ascii=False)
        # print(formatted_response)

    def test_user_repay_loan_by_account(self):
        request = {
            "identity_card": self.olineUser.identity_card,
            "account_id": self.account.account_id,
            "loan_id": self.loanRecord.loan_id
        }

        response = self.client.post(reverse('user_repay_loan_by_account'), data=request)
        response_content = response.content.decode('utf-8')
        formatted_response = json.dumps(json.loads(response_content), indent=4, ensure_ascii=False)
        print(formatted_response)

    def test_search_all_need_repay_loan_record(self):
        request = {
            "person_id": self.olineUser.person_id
        }

        response = self.client.post(reverse('search_all_need_repay_loan_record'), data=request)
        self.assertEqual(response.status_code, 200)
        # print(response.content.decode())

    def test_unrepay_loan_record_reminder(self):
        request = {
            "person_id": self.olineUser.person_id
        }

        response = self.client.post(reverse('unrepay_loan_record_reminder'), data=request)
        self.assertEqual(response.status_code, 200)
        # print(response.content.decode())