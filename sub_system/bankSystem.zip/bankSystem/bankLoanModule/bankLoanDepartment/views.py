from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from dateutil.relativedelta import relativedelta
from django.db import transaction, connection
from django.forms.models import model_to_dict
from django.http import JsonResponse
from django.core import serializers
from bankDatabase import models
from django.utils import timezone
import datetime
import json

@csrf_exempt
@require_http_methods(["POST"])
def commitLoanApplication(request):
    ''' 用户提交贷款申请 smoke successful 6.8前后端ok '''

    response = {}
    with transaction.atomic():
        try:
            body_unicode = request.body.decode('utf-8')
            body = json.loads(body_unicode)

            identity_card = body.get('identity_card')
            account_id = body.get('account_id')
            amount = body.get('amount')
            loan_duration = body.get('loan_duration')
            # print(identity_card, account_id, amount, loan_duration)

            remark = "This is remark about the loan application"
            if body.get('remark') is not None:
                remark = body.get('remark')

            # There may be models.DoesNotExist errors
            check_account = models.Account.objects.get(account_id=account_id)
            if check_account.card_type != 1:
                raise Exception("Error! It is not possible to borrow a loan without a credit card")
            if identity_card != check_account.identity_card:
                raise Exception("Error! The owner of the card number is not you!")

            models.LoanApplication.objects.create(identity_card=identity_card, account_id=check_account,
                                                  amount=amount, loan_duration=loan_duration, remark=remark)

            response['response_code'] = 1
            response['response_message'] = "Loan application commit successfully, the apllication date is " + str(
                datetime.datetime.now())
        except Exception as e:
            response['response_code'] = 0
            response['response_message'] = str(e)
            print("Error!" + str(e))

    return JsonResponse(response)

@csrf_exempt
@require_http_methods(['POST'])
def searchAllNeedRepayLoanRecord(request):
    ''' 用户查询所有需要还款的贷款 smoke successful 6.8前后端ok '''

    response = {}
    try:
        body_unicode = request.body.decode('utf-8')
        body = json.loads(body_unicode)

        identity_card = body.get('identity_card')
        user = models.OlineUser.objects.get(identity_card=identity_card)
        accounts = models.Account.objects.filter(card_type=1, identity_card=user.identity_card)
        loan_applications = models.LoanApplication.objects.filter(
            account_id__in=accounts.values_list('account_id', flat=True)
        )
        loan_records = models.LoanRecord.objects.filter(
            application_id__in=loan_applications.values_list('application_id', flat=True)
        )

        loan_records = loan_records.filter(is_repay=False)

        loan_record_list = []
        for loan_record in loan_records:
            loan_record_map = {}
            loan_record_map['loan_id'] = loan_record.loan_id
            loan_application = models.LoanApplication.objects.get(application_id=loan_record.application_id_id)
            loan_record_map['account_id'] = loan_application.account_id_id
            loan_record_map['amount'] = loan_application.amount
            loan_record_map['end_time'] = str(loan_record.end_time)
            loan_record_list.append(loan_record_map)
        print(loan_record_list)

        response['response_code'] = 1
        response['response_message'] = "Check the records of all loans that need to be repaid successfully"
        response['loan_application_list'] = loan_record_list
    except Exception as e:
        response['response_code'] = 0
        response['response_message'] = str(e)

    return JsonResponse(response)

@csrf_exempt
@require_http_methods(['POST'])
def unrepayLoanRecordReminder(request):
    ''' 用户贷款还款提醒 smoke successful 6.8前后端ok '''

    response = {}
    try:
        body_unicode = request.body.decode('utf-8')
        body = json.loads(body_unicode)

        identity_card = body.get("identity_card")
        accounts = models.Account.objects.filter(identity_card=identity_card)
        loan_applications = models.LoanApplication.objects.filter(
            account_id__in=accounts.values_list("account_id", flat=True)
        )
        loan_records = models.LoanRecord.objects.filter(
            application_id__in=loan_applications.values_list("application_id", flat=True)
        )

        count = 0
        current_time = timezone.now()
        for record in loan_records:
            if current_time < record.end_time < current_time + datetime.timedelta(days=7):
                count += 1

        response['response_code'] = 1
        response['response_message'] = f"You have a record of {count} loans that need to be repaid within 7 days"
    except Exception as e:
        response['response_code'] = 0
        response['response_message'] = str(e)
        print(str(e))

    return JsonResponse(response)

@csrf_exempt
@require_http_methods(['POST'])
def searchAllLoanApplicationByUser(request):
    ''' 用户贷款查询界面返回其所有的贷款记录 smoke successful 前后端ok '''

    response = {}
    try:
        body_unicode = request.body.decode('utf-8')
        body = json.loads(body_unicode)

        identity_card = body.get('identity_card')
        print(identity_card)
        loan_applications = models.LoanApplication.objects.filter(identity_card=identity_card)
        print(loan_applications)

        '''
        add a feature named stauts, the status has six possible values:
        待审核、审核拒绝、待放款、拒绝放款、待还款和已还款
        '''

        loan_application_list = []
        for loan_application in loan_applications:
            loan_application_map = {}
            loan_application_map['application_id'] = loan_application.application_id
            loan_application_map['account_id'] = loan_application.account_id_id
            loan_application_map['application_data'] = str(loan_application.application_data)
            loan_application_map['amount'] = loan_application.amount
            if models.LoanApproval.objects.filter(application_id=loan_application).exists():
                loan_approval = models.LoanApproval.objects.get(application_id=loan_application)

                if loan_approval.result == False:
                    loan_application.status = '审批拒绝'
                else:
                    if models.Lender.objects.filter(application_id=loan_application).exists():
                        lender = models.Lender.objects.get(application_id=loan_application)

                        if lender.result == False:
                            loan_application.status = '拒绝放款'
                        else:
                            loan_record = models.LoanRecord.objects.get(application_id=loan_application)
                            if loan_record.is_repay:
                                loan_application.status = '已还款'
                            else:
                                loan_application.status = '待还款'
                    else:
                        loan_application.status = '待放款'

            else:
                loan_application.status = '待审批'
            loan_application.save()
            loan_application_map['status'] = loan_application.status
            loan_application_list.append(loan_application_map)

        print(loan_application_list)

        response['response_code'] = 1
        response['response_message'] = "Query all loan applications with status feature of users"
        response['loan_application_list'] = loan_application_list
    except Exception as e:
        response['response_code'] = 0
        response['response_message'] = str(e)

    return JsonResponse(response)

# 前端完成了以下两个函数
def searchLoanApplicationByAccount(request):
    ''' 用户通过银行卡号查询贷款记录 '''
    response = {}
    pass

def searchLoanApplicationByStatus(request):
    ''' 用户通过贷款状态查询贷款记录 '''
    response = {}
    pass


'''
        2024.6.3
        由于银行卡的余额计算问题
凡是设计余额变更的需要等待合并后的函数change_balance(行级锁)
        包括还款的余额判断
'''

# 若用户一直不还款则不会逾期？添加数据库定期维护
@csrf_exempt
@require_http_methods(['POST'])
def userRepayLoanByAccount(request):
    ''' 用户使用单张银行卡还款 6.8前后端ok '''

    response = {}
    with transaction.atomic():
        try:
            print(request.body)
            body_unicode = request.body.decode('utf-8')
            body = json.loads(body_unicode)

            identity_card = body.get('identity_card')
            account_id = body.get('account_id')
            loan_id = body.get('loan_id')
            print(identity_card, account_id, loan_id)
            loan_record = models.LoanRecord.objects.get(loan_id=loan_id)

            # determine the owner and balance of the card
            check_account = models.Account.objects.get(account_id=account_id)
            if identity_card != check_account.identity_card:
                raise Exception("Error! The owner of the card number is not you!")
            amount = loan_record.application_id.amount
            # 待定修改
            if check_account.uncredited_deposit < amount:
                raise Exception("Error! The balance of this card is not enough to repay the loan!")

            # determine wheather is overdue, > means later
            is_overdue = False
            print(loan_record.end_time, timezone.now())
            if loan_record.end_time < timezone.now():
                is_overdue = True

            if loan_record.is_repay:
                raise Exception("Error! Repayment records already exist!")

            models.LoanRepayment.objects.create(
                loan_id=loan_record,
                is_overdue=is_overdue,
                remark="This is remark about the loan repayment"
            )
            # 调用函数change_balance
            check_account.balance -= amount
            check_account.current_deposit -= amount
            loan_record.is_repay = True
            check_account.save()
            loan_record.save()

            response['response_code'] = 1
            response['response_message'] = "The repayment is successful, and the credit card balance is deducted"
        except Exception as e:
            response['response_code'] = 0
            response['response_message'] = str(e)
            print(str(e))

    return JsonResponse(response)

@csrf_exempt
def showAllLoanApplicationUnapproved(request):
    ''' 贷款审核员界面显示所有未审批的贷款申请 smoke successful 6.8前后端ok '''

    response = {}
    try:
        loan_approvals = models.LoanApproval.objects.all()
        # exclude remove those that meet the conditions, __in indicates that it exists in its list
        unapproved_applications = models.LoanApplication.objects.exclude(
            application_id__in=loan_approvals.values_list('application_id', flat=True)
        )

        # 2024.6.3 添加一个信息显示该信用卡已贷但未还的金额
        unapproved_application_list = []
        for unapproved_application in unapproved_applications:
            unapproved_application_map = {}
            account_id = unapproved_application.account_id_id
            loan_applications = models.LoanApplication.objects.filter(account_id=account_id, status="待还款")
            lentMoney = 0
            for loan_application in loan_applications:
                lentMoney += loan_application.amount
            account = models.Account.objects.get(account_id=unapproved_application.account_id_id)
            account.lent_money = lentMoney
            account.save()

            unapproved_application_map['identity_card'] = unapproved_application.identity_card
            unapproved_application_map['account_id'] = unapproved_application.account_id_id
            unapproved_application_map['amount'] = unapproved_application.amount
            unapproved_application_map['loan_duration'] = unapproved_application.loan_duration
            unapproved_application_map['application_data'] = str(unapproved_application.application_data)
            unapproved_application_map['credit_limit'] = account.credit_limit
            unapproved_application_map['lent_money'] = account.lent_money
            unapproved_application_map['application_id'] = unapproved_application.application_id
            unapproved_application_list.append(unapproved_application_map)

        print(unapproved_application_list)

        response['response_code'] = 1
        response['response_message'] = "Find all unapproved loan records"
        response['unapproved_application_list'] = unapproved_application_list
    except Exception as e:
        response['response_code'] = 0
        response['response_message'] = str(e)

    return JsonResponse(response)

@csrf_exempt
def showAllLoanApplicationUnlent(request):
    ''' 贷款部门经理界面显示所有未放款的已审批通过的贷款记录 smoke successful 6.8前后端ok '''

    response = {}
    try:
        loan_approvals = models.LoanApproval.objects.filter(result=True)
        lenders = models.Lender.objects.all()
        # The judgment conditions have been approved and the loan has not been disbursed
        unlent_approvals = loan_approvals.exclude(
            application_id__in=lenders.values_list('application_id', flat=True)
        )

        unlent_approval_list = []
        for unlent_approval in unlent_approvals:
            unlent_approval_map = {}
            loan_application = models.LoanApplication.objects.get(application_id=unlent_approval.application_id_id)
            unlent_approval_map['identity_card'] = loan_application.identity_card
            unlent_approval_map['account_id'] = loan_application.account_id_id
            unlent_approval_map['amount'] = loan_application.amount
            unlent_approval_map['loan_duration'] = loan_application.loan_duration
            unlent_approval_map['approval_id'] = unlent_approval.approval_id
            unlent_approval_list.append(unlent_approval_map)

            print(unlent_approval_list)

        response['response_code'] = 1
        response['response_message'] = "Query the loan records of all pending loans"
        response['unlent_approval_list'] = unlent_approval_list
    except Exception as e:
        response['response_code'] = 0
        response['response_message'] = str(e)

    return JsonResponse(response)

@csrf_exempt
def updateCreditLimit(request):
    ''' 更新用户信用卡的信用额度 '''
    response = {}
    try:
        body_unicode = request.body.decode('utf-8')
        body = json.loads(body_unicode)

        user_id = body.get('user_id')
        # Obtain the user's annual income, property valuation, and occupation category from the database
        user_data = models.UserData.objects.get(user_id=user_id)

        annual_income = user_data.annual_income
        property_valuation = user_data.property_valuation
        occupational_type = user_data.occupational_type

        # Calculate the credit line
        credit_limit = (0.7 * annual_income * 1.0 + 0.8 * property_valuation) * occupational_type

        # Update the user's credit limit
        user_data.credit_limit = credit_limit
        user_data.save()

        response['response_code'] = 1
        response['response_message'] = "Credit limit updated successfully"
        response['credit_limit'] = credit_limit

    except models.UserData.DoesNotExist:
        response['response_code'] = 0
        response['response_message'] = "User data not found"
    except Exception as e:
        response['response_code'] = 0
        response['response_message'] = str(e)

    return JsonResponse(response)

# The next operations require locking the database
@csrf_exempt
@require_http_methods(['POST'])
def approvalLoanApplication(request):
    ''' 贷款审核员审批贷款申请 smoke successful 前后端待测6.8 '''

    response = {}
    with transaction.atomic():
        try:
            body_unicode = request.body.decode('utf-8')
            body = json.loads(body_unicode)

            result = body.get("result")
            loan_examiner_id = body.get("loan_examiner_id")
            application_id = body.get("application_id")
            print(result, loan_examiner_id, application_id)
            loan_examiner = models.LoanExaminer.objects.get(loan_examiner_id=loan_examiner_id)

            if models.LoanApproval.objects.filter(application_id=application_id).exists():
                raise Exception("Error! The loan application has been approved!")
            loan_application = models.LoanApplication.objects.get(application_id=application_id)

            models.LoanApproval.objects.create(
                loan_examiner_id=loan_examiner,
                application_id=loan_application,
                result=result,
                remark="This is remark about the loan approval"
            )

            response['response_code'] = 1
            response['response_message'] = f"The loan examiner{loan_examiner_id} approves the loan application{application_id} and the structure is {result}"
        except Exception as e:
            response['response_code'] = 0
            response['response_message'] = str(e)

    return JsonResponse(response)

@csrf_exempt
@require_http_methods(['POST'])
def lenderLoanApplication(request):
    ''' 贷款部门经理放款 smoke successful 6.8前后端ok '''

    response = {}
    with transaction.atomic():
        try:
            print(request.body)
            body_unicode = request.body.decode('utf-8')
            body = json.loads(body_unicode)

            loan_manager_id = body.get("loan_manager_id")
            approval_id = body.get("approval_id")
            result = body.get("result")
            print(loan_manager_id, approval_id, result)
            loan_manager = models.LoanDepartmentManager.objects.get(loan_manager_id=loan_manager_id)
            loan_approval = models.LoanApproval.objects.get(approval_id=approval_id)
            application_id = loan_approval.application_id_id
            loan_application = models.LoanApplication.objects.get(application_id=application_id)
            print(1)

            if models.Lender.objects.filter(application_id=application_id).exists() or models.LoanRecord.objects.filter(application_id=application_id).exists():
                raise Exception("Error! The loan application has been lent!")

            '''
            放款的步骤为:生成放款记录，生成贷款记录，给用户卡号余额添加amount
            '''
            print(2)
            models.Lender.objects.create(
                loan_manager_id=loan_manager,
                application_id=loan_application,
                result=result,
                remark="This is remark about the lender"
            )
            print(3)

            now_time = datetime.datetime.now()
            loan_record = models.LoanRecord(
                loan_examiner_id=loan_approval.loan_examiner_id,
                loan_manager_id=loan_manager,
                application_id=loan_application,
                effective_date=now_time,
                remark="This is remark about the loan record"
            )
            loan_record.setEndTime(loan_application.loan_duration)
            loan_record.save()
            print(4)

            account = models.Account.objects.get(account_id=loan_application.account_id_id)
            # 等待函数change_balance
            account.balance += loan_application.amount
            account.uncredited_deposit += loan_application.amount
            account.save()
            print(5)

            response['response_code'] = 1
            response['response_message'] = f"The loan application{application_id} was issued by the loan department manager{loan_manager_id}" \
                                           f" and the result was {result}.At the same time, a loan record{loan_record.loan_id} is generated"
        except Exception as e:
            response['response_code'] = 0
            response['response_message'] = str(e)

    return JsonResponse(response)