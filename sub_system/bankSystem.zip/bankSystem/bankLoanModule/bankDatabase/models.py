from django.db import models
from dateutil.relativedelta import relativedelta
from django.contrib.auth.hashers import make_password, check_password

class AuthorityEmployee(models.Model):
    employee_id = models.AutoField(primary_key=True)               # default auto-increment primary key
    # there's no need to distinguish between varchar and char here because it's form data
    employee_name = models.CharField(max_length=20)
    identity_card = models.CharField(max_length=18)
    employee_sex = models.IntegerField()
    phone_number = models.CharField(max_length=20)
    occupation_name = models.CharField(max_length=50)
    is_employeed = models.BooleanField(default=True)
    other_information = models.TextField(default="This is additional information from the authority employee")
    objects = models.Manager()

    class Meta:
        db_table = "authority_employee"
        verbose_name = "authority employee"

    def __str__(self):
        if self.is_employeed:
            return f"employee_id={self.employee_id}, employee_name={self.employee_name}, occupation_name={self.occupation_name}"
        else:
            return "He/she has been fired"

class SysManager(models.Model):
    sys_manager_id = models.AutoField(primary_key=True)
    # foreign key automatically matchs the same attribute name
    # on_delete=models.CASCADE denote cascading delete
    employee_id = models.ForeignKey(AuthorityEmployee, on_delete=models.CASCADE, db_column="employee_id")
    account = models.CharField(max_length=100)
    password = models.CharField(max_length=1024)
    other_information = models.TextField(default="This is additional information from the system manager")
    objects = models.Manager()

    class Meta:
        db_table = "sys_manager"
        verbose_name = "system manager"

    def __str__(self):
        return f"employee_id={self.employee_id}, sys_manager_id={self.sys_manager_id}, account={self.account}"

    def setPassword(self, row_password):
        self.password = make_password(password=row_password)

    def checkPassword(self, row_password):
        return check_password(row_password, self.password)

class LoanDepartmentManager(models.Model):
    loan_manager_id = models.AutoField(primary_key=True)
    employee_id = models.ForeignKey(AuthorityEmployee, on_delete=models.CASCADE, db_column="employee_id")
    account = models.CharField(max_length=100)
    password = models.CharField(max_length=1024)
    other_information = models.TextField(default="This is additional information from the loan department manager")
    objects = models.Manager()

    class Meta:
        db_table = "loan_department_manager"
        verbose_name = "loan department manager"

    def __str__(self):
        return f"employee_id={self.employee_id}, loan_manager_id={self.loan_manager_id}, account={self.account}"

    def setPassword(self, row_password):
        self.password = make_password(password=row_password)

    def checkPassword(self, row_password):
        return check_password(row_password, self.password)

class LoanExaminer(models.Model):
    loan_examiner_id = models.AutoField(primary_key=True)
    employee_id = models.ForeignKey(AuthorityEmployee, on_delete=models.CASCADE, db_column="employee_id")
    account = models.CharField(max_length=100)
    password = models.CharField(max_length=1024)
    other_information = models.TextField(default="This is additional information from the loan examiner")
    objects = models.Manager()

    class Meta:
        db_table = "loan_examiner"
        verbose_name = "loan examiner"

    def __str__(self):
        return f"employee_id={self.employee_id}, loan_examiner_id={self.loan_examiner_id}, account={self.account}"

    def setPassword(self, row_password):
        self.password = make_password(password=row_password)

    def checkPassword(self, row_password):
        return check_password(row_password, self.password)

class OlineUser(models.Model):
    person_id = models.AutoField(primary_key=True)
    phone_number = models.CharField(max_length=20)
    identity_card = models.CharField(max_length=18)
    person_name = models.CharField(max_length=100)
    password = models.CharField(max_length=1024)
    sex = models.IntegerField()
    trading_authority = models.BooleanField(default=True)
    loan_authority = models.BooleanField(default=True)
    foreign_exchange_authority = models.BooleanField(default=True)
    annual_income = models.FloatField(null=True)
    property_valuation = models.FloatField(null=True)
    occupational_type = models.CharField(max_length=20, null=True)
    service_year = models.IntegerField(null=True)
    objects = models.Manager()

    class Meta:
        db_table = "online_user"
        verbose_name = "online user"

    def __str__(self):
        return f"person_id={self.person_id}, person_name={self.person_name}, identity_card={self.identity_card}"

    def setPassword(self, row_password):
        self.password = make_password(password=row_password)

    def checkPassword(self, row_password):
        return check_password(row_password, self.password)

class Account(models.Model):
    account_id = models.AutoField(primary_key=True)
    password = models.CharField(max_length=1024)
    identity_card = models.CharField(max_length=18)
    card_type = models.IntegerField()
    balance = models.FloatField()
    current_deposit = models.FloatField()
    uncredited_deposit = models.FloatField()
    credit_limit = models.FloatField(default=10000)
    lent_money = models.FloatField(null=True)
    is_frozen = models.BooleanField(default=False)
    is_lost = models.BooleanField(default=False)
    objects = models.Manager()

    class Meta:
        db_table = "account"
        verbose_name = "account"

    def __str__(self):
        if self.card_type:
            return f"account_id={self.account_id}, card_type=credit card, balance={self.balance}"
        else:
            return f"account_id={self.account_id}, card_type=memory card, balance={self.balance}"

    def setPassword(self, row_password):
        self.password = make_password(password=row_password)

    def checkPassword(self, row_password):
        return check_password(row_password, self.password)

# The following is the data structure of the service
class DepositRecord(models.Model):
    deposit_record_id = models.AutoField(primary_key=True)
    account_id = models.ForeignKey(Account, on_delete=models.CASCADE, db_column="account_id")
    deposit_type = models.CharField(max_length=20)
    auto_renew_status = models.BooleanField(null=True)
    deposit_start_date = models.DateTimeField(auto_now_add=True)
    deposit_end_date = models.DateTimeField(null=True)
    deposit_amount = models.FloatField()
    cashier_id = models.IntegerField()
    objects = models.Manager()

    class Meta:
        db_table = "deposit_record"
        verbose_name = "deposit record"

class WithdrawalRecord(models.Model):
    withdrawal_record_id = models.AutoField(primary_key=True)
    account_id = models.ForeignKey(Account, on_delete=models.CASCADE, db_column="account_id")
    withdrawal_date = models.DateTimeField(auto_now_add=True)
    withdrawal_amount = models.FloatField()
    cashier_id = models.IntegerField()
    objects = models.Manager()

    class Meta:
        db_table = "withdrawal_record"
        verbose_name = "withdrawal record"

class TransferRecord(models.Model):
    transfer_record_id = models.AutoField(primary_key=True)
    account_in_id = models.IntegerField()
    account_out_id = models.IntegerField()
    transfer_date = models.DateTimeField(auto_now_add=True)
    transfer_amount = models.FloatField()
    cashier_id = models.IntegerField()
    objects = models.Manager()

    class Meta:
        db_table = "transfer_record"
        verbose_name = "transfer record"

class LoanApplication(models.Model):
    application_id = models.AutoField(primary_key=True)
    identity_card = models.CharField(max_length=18)
    account_id = models.ForeignKey(Account, on_delete=models.CASCADE, db_column="account_id")
    amount = models.FloatField()
    application_data = models.DateTimeField(auto_now_add=True)
    loan_duration = models.IntegerField()
    status = models.CharField(max_length=100, null=True)
    remark = models.TextField(default="This is remark about the loan application")

    class Meta:
        db_table = "loan_application"
        verbose_name = "loan application"

    def __str__(self):
        return f"application_id={self.application_id}, identity_card={self.identity_card}, account_id={self.account_id}, amount={self.amount}"

class LoanApproval(models.Model):
    approval_id = models.AutoField(primary_key=True)
    loan_examiner_id = models.ForeignKey(LoanExaminer, on_delete=models.CASCADE, db_column="loan_examiner_id")
    application_id = models.ForeignKey(LoanApplication, on_delete=models.CASCADE, db_column="application_id")
    result = models.BooleanField()
    approval_date = models.DateTimeField(auto_now_add=True)
    remark = models.TextField(default="This is remark about the loan approval")
    objects = models.Manager()

    class Meta:
        db_table = "loan_approval"
        verbose_name = "loan approval"

    def __str__(self):
        return f"approval_id={self.approval_id}, loan_examiner_id={self.loan_examiner_id}, application_id={self.application_id}, result={self.result}"

class Lender(models.Model):
    lender_id = models.AutoField(primary_key=True)
    loan_manager_id = models.ForeignKey(LoanDepartmentManager, on_delete=models.CASCADE, db_column="loan_manager_id")
    application_id = models.ForeignKey(LoanApplication, on_delete=models.CASCADE, db_column="application_id")
    result = models.BooleanField()
    lender_date = models.DateTimeField(auto_now_add=True)
    remark = models.TextField(default="This is remark about the lender")
    objects = models.Manager()

    class Meta:
        db_table = "lender"

''' 
在放款之后产生一个贷款记录用来监控后期还款以及实现还款提醒
因此需要通过lender记录计算其end_time
'''
class LoanRecord(models.Model):
    loan_id = models.AutoField(primary_key=True)
    loan_examiner_id = models.ForeignKey(LoanExaminer, on_delete=models.CASCADE, db_column="loan_examiner_id")
    loan_manager_id = models.ForeignKey(LoanDepartmentManager, on_delete=models.CASCADE, db_column="loan_manager_id")
    application_id = models.ForeignKey(LoanApplication, on_delete=models.CASCADE, db_column="application_id")
    effective_date = models.DateTimeField(auto_now_add=True)
    end_time = models.DateTimeField(null=True)
    is_repay = models.BooleanField(default=False)
    remark = models.TextField(default="This is remark about the loan record")
    objects = models.Manager()

    class Meta:
        db_table = "loan_record"
        verbose_name = "loan record"

    def setEndTime(self, loan_duration):
        self.end_time = self.effective_date + relativedelta(months=loan_duration)

class LoanRepayment(models.Model):
    repayment_id = models.AutoField(primary_key=True)
    loan_id = models.ForeignKey(LoanRecord, on_delete=models.CASCADE, db_column="loan_id")
    repayment_date = models.DateTimeField(auto_now_add=True)
    is_overdue = models.BooleanField(default=False)
    remark = models.TextField(default="This is remark about the loan repayment")
    objects = models.Manager()

    class Meta:
        db_table = "loan_repayment"
        verbose_name = "loan repayment"