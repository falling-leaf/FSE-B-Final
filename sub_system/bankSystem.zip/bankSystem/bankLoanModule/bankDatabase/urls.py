import datetime

from django.urls import path
from . import views

app_name = "bankDatabase"
urlpatterns = [
    path('', views.getAuthorityEmployee),
    path('addEmployeeRecord/', views.addTestEmployeeRecord, name='addEmployeeRecord'),
    path('addUserAccountRecord/', views.addTestUserAccountRecord, name='addUserAccountRecord'),
]

# from .models import LoanRecord
# from django.db import transaction
# from django.utils import timezone
# from django_apscheduler.jobstores import DjangoJobStore, register_job
# from apscheduler.schedulers.background import BackgroundScheduler
#
# scheduler = BackgroundScheduler()
# scheduler.add_jobstore(DjangoJobStore(), "default")
#
# @register_job(scheduler, 'cron', hour="*/12", minute='0', second='0',
#               replace_existing=True, timezone='Asia/Shanghai',
#               id="update_loan_record_isoverdue")
# def update_loan_record_isoverdue():
#     with transaction.atomic():
#         try:
#             loan_records = LoanRecord.objects.filter(is_repay=False)
#             current_time = timezone.now()
#             for loan_record in loan_records:
#                 if loan_record.end_time < current_time:
#                     loan_record.is_overdue = True
#
#             print(str(datetime.datetime.now()) + "是否逾期信息更新成功")
#         except Exception as e:
#             print(str(e))
#
# scheduler.start()