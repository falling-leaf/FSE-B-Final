from django.core import serializers
from django.http import HttpResponse
from . import models
def getAuthorityEmployee(request):
    data = models.AuthorityEmployee.objects.filter(employee_name="吴承恩").exists()
    return HttpResponse(data)

def addTestEmployeeRecord(request):
    try:
        employee1 = models.AuthorityEmployee.objects.create(employee_name="吴承恩", identity_card="330215789354120315",
                                                            employee_sex=1, phone_number="18205776812",
                                                            occupation_name="贷款审核员", is_employeed=1,
                                                            other_information="This is additional information from the authority employee")
        employee2 = models.AuthorityEmployee.objects.create(employee_name="孙若飞", identity_card="30212548651646848X",
                                                            employee_sex=1, phone_number="15642828635",
                                                            occupation_name="贷款部门经理", is_employeed=1,
                                                            other_information="This is additional information from the authority employee")
        employee3 = models.AuthorityEmployee.objects.create(employee_name="比尔盖茨",
                                                            identity_card="342314732984359843",
                                                            employee_sex=0, phone_number="12423432554",
                                                            occupation_name="系统管理员", is_employeed=1,
                                                            other_information="This is additional information from the authority employee")

        sysmanager = models.SysManager(employee_id=employee3, account="sysmanager",
                                       other_information="This is additional information from the system manager")
        sysmanager.setPassword("123456789")
        sysmanager.save()

        loanExaminer = models.LoanExaminer(employee_id=employee1, account="loanexaminer",
                                           other_information="This is additional information from the loan examiner")
        loanExaminer.setPassword("123456789")
        loanExaminer.save()

        loanManager = models.LoanDepartmentManager(employee_id=employee2, account="loanmanager",
                                                   other_information="This is additional information from the loan department manager")
        loanManager.setPassword("123456789")
        loanManager.save()
    except Exception as e:
        return HttpResponse("add employee record failed" + str(e))

    return HttpResponse("add employee record successfully")

def addTestUserAccountRecord(request):
    try:
        user1 = models.OlineUser(phone_number="18205876813", identity_card="330204197508260578", person_name="张三",
                                sex=1, trading_authority=1, loan_authority=1, foreign_exchange_authority=1,
                                annual_income=15000, property_valuation=600000, occupational_type="教师", service_year=10)
        user1.setPassword("123456789")
        user1.save()
        user2 = models.OlineUser(phone_number="18212354827", identity_card="33020420020916082X", person_name="李四",
                                sex=1, trading_authority=1, loan_authority=1, foreign_exchange_authority=1,
                                annual_income=5000, property_valuation=10000, occupational_type="Java工程师", service_year=5)
        user2.setPassword("123456789")
        user2.save()

        account1 = models.Account(identity_card=user1.identity_card, card_type=1, balance=250000, current_deposit=150000,
                                  uncredited_deposit=100000, is_frozen=0, is_lost=0)
        account1.setPassword("123456789")
        account1.save()

        account2 = models.Account(identity_card=user2.identity_card, card_type=1, balance=25000, current_deposit=15000,
                                  uncredited_deposit=10000, is_frozen=0, is_lost=0)
        account2.setPassword("123456789")
        account2.save()
    except Exception as e:
        return HttpResponse("add user and account record failed" + str(e))

    return HttpResponse("add user and account record successfully")